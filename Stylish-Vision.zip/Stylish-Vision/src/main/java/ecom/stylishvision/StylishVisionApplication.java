package ecom.stylishvision;

import ecom.stylishvision.Model.Category;
import ecom.stylishvision.Model.Produits;
import ecom.stylishvision.Repository.CategoryRepository;
import ecom.stylishvision.Repository.ProduitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Random;

@SpringBootApplication
public class StylishVisionApplication implements CommandLineRunner {
    @Autowired
    private ProduitRepository produitRepository;
    @Autowired
    private CategoryRepository categoryRepository;


    public static void main(String[] args) {
        SpringApplication.run(StylishVisionApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {



        categoryRepository.save(new Category(1,"sunglasses",null));
        categoryRepository.save(new Category(2,"Glasses",null));

        categoryRepository.findAll().forEach(category ->{
            Produits p=new Produits();
            p.setTitle("lunette fille ");
            p.setCategory(category);
            p.setMarque("mecvuiton");
            p.setPrix(55);
            produitRepository.save(p);
        } );

    }
}
