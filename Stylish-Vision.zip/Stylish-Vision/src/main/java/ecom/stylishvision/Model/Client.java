package ecom.stylishvision.Model;

public class Client {
    private long id ;
    private String nomComplet;
    private String email;
    private String telephone;
    private String adresseLivraison;
    private String carteBanquaire;
}
