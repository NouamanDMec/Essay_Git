package ecom.stylishvision.Model;

public class Admin {
    private long id ;
    private String nomComplet;
    private String cin;
    private String email;
    private String mdp;

}
