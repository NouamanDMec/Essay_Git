package ecom.stylishvision.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

@Entity
@Data @NoArgsConstructor @AllArgsConstructor @ToString

public class Produits implements Serializable {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String marque;
    private String photo;
    private Integer quantite;
    private double prix;
    private String description;
    @ManyToOne
    private Category category;


}
