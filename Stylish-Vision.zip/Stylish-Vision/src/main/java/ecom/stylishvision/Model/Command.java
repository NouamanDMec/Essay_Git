package ecom.stylishvision.Model;

import java.util.Date;

public class Command {
    private long id_command;
    private long id_client;
    private String Ref_produit;
    private Date date_command;
    private double montantArticle;
    private double montantLivraison;
    private double montantTotale;
    private String methodePaiement;
}
