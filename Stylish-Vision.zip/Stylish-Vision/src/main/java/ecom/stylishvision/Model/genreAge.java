package ecom.stylishvision.Model;

public class genreAge {
    private long id;
    private String nom;
}
