package ecom.stylishvision.Model;

public class Design {
    private long id ;
    private String design;
}
